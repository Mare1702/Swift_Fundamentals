import UIKit
/*USO DE OPCIONALES*/
/// Nil (nulo)
struct Book {
  var name: String
  var publicationYear: Int
}

let firstHarryPotter = Book(name: "Harry Potter y la piedra filosofal", publicationYear: 1997)
let secondHarryPotter = Book(name: "Harry Potter y la cámara secreta", publicationYear: 1998)
let thirdHarryPotter = Book(name: "Harry Potter y el prisionero de Azkaban", publicationYear: 1999)

let books = [firstHarryPotter, secondHarryPotter, thirdHarryPotter]

let unannouncedBook1 = Book(name: "Rebeldes y leones", publicationYear: 0)

let unannouncedBook2 = Book(name: "Rebeldes y leones", publicationYear: 2023)

//let unannouncedBook3 = Book(name: "Rebeldes y leones", publicationYear: nil)

//Especificar el tipo

var serverResponseCode = 404 //Int, no Int?

//var serverResponseCode1 = nil //Error, no se especifico un tipo cuando no es nil

var serverResponseCode3:Int? = 404 //Establecido en 404 pero podria ser "nil" mas adelante

var serverResponseCode4:Int? = nil// establecido nil pero podria ser Int mas adelante


///Trabajar con valores opcionales
var publicationYear1: Int? = nil

if publicationYear1 != nil {
    let actualYear = publicationYear1!
    print(actualYear)
}

/*let unwrappedYear = publicationYear1!//Error en tiemo de ejecucion
print(unwrappedYear)*/

if let unwrappedYear1 = publicationYear1 {
    print("El libro se publico en \(unwrappedYear1)")
} else {
    print("El libro no tiene año de publicacion")
}

///// funciones y opcionales
///
let string = "123"
let posibleNumber = Int(string)
let string1 = "s"
let possibleNumber1 = Int(string1)

func printFullName(firstName: String, middleName: String?, lastName: String){
    if let middle = middleName {
        print("Tu nombre es \(firstName) \(middle) \(lastName)")
    }else {
        print("Tu nombre es \(firstName) \(lastName)")
    }
}
printFullName(firstName: "Marcos", middleName: "Uriel", lastName: "Mtz")

func tienesHambre(Respuesta: String) -> String? {
    if Respuesta == "Si" {
        return "Quiero unas alitas"
    }else if Respuesta == "No"{
        return nil
    }else {
        return nil
    }
}
if let hambre = tienesHambre(Respuesta: "Si"){
    print(hambre)
}
///inicializadores Falibles
struct Toddler {
    var name: String
    var mountsOld: Int
    
    init?(name: String, mountsOld: Int){
        if mountsOld < 12 || mountsOld > 36 {
            return nil
        }else {
            self.name = name
            self.mountsOld = mountsOld
        }
    }
}

if let niño = Toddler(name: "Pablito", mountsOld: 15){
    print("hola \(niño.name), tienes \(niño.mountsOld) meses")
} else {
    print("El niño no cumple con los requerimentos de edad")
}


struct Person {
    var age: Int
    var residence: Residence?
}

struct Residence {
    var address: Address?
}

struct Address {
    var buildingNumber: String
    var streetName: String
    var apartmentNumber: String?
}
////encadenamiento opcional
let person = Person(age: 21,residence: Residence(address: Address(buildingNumber: "21", streetName: "Zaragoza",apartmentNumber: "3")))

if let theResidence = person.residence {
    if let theAdreess = theResidence.address {
        if let theApartmentNumber = theAdreess.apartmentNumber {
            print("Vives en el departamento \(theApartmentNumber)")
        }else{
            print("Esta persona vive en casa propia")
        }
    }
}

if let theApartmentNumber = person.residence?.address?.apartmentNumber {
    print("Vives en el departamento \(theApartmentNumber), feliz dia")
}else {
    print("Esta persona vive en casa propia, feliz dia")
}



/*USO DE GUARD*/
//guard
var birthDayIsToday: Bool = true
var invitedGuests: [String] = ["Marcos"]
var cakeCandlesLit: Bool = false


func singHappyBirthday() {
    if birthDayIsToday {
        if !invitedGuests.isEmpty {
            if cakeCandlesLit {
                print("¡Feliz Cumpleaños!")
            } else {
                print("No se han encendido las velas del pastel")
            }
        }else {
            print("Solo es una fiesta familiar")
        }
    }else {
        print("Nadie cumple años hoy")
    }
}

singHappyBirthday()


func singHappyBirthday1() {
    if !birthDayIsToday {
        print("Nadie cumple años hoy")
        return
    }
    
    if invitedGuests.isEmpty {
        print("Solo es una fiesta familiar")
        return
    }
    
    if cakeCandlesLit == false   {
        print("No se han encendido las velas del pastel")
        return
    }
    
    print("¡Feliz cumpleaños!")
}

singHappyBirthday1()

func singHappyBirthdayGuard() {
    guard birthDayIsToday else {
        print("Nadie cumple años hoy")
        return
    }
    
    guard !invitedGuests.isEmpty else {
        print("Solo es una fiesta familiar")
        return
    }
    
    guard cakeCandlesLit else {
        print("No se han prendido las velas del pastel")
        return
    }
    
    print("¡Ferliz cumpleaños!")
}

singHappyBirthdayGuard()

func divide(_ number:Double, by divisor: Double){
    if divisor != 0.0 {
        let result = number/divisor
        print(result)
    }
}
divide(2.9, by: 2.9)
func divideGuard(_ number: Double,by divisor: Double) {
    guard divisor != 0.0 else  {
        return
    }
    let result = number/divisor
    print(result)
}

divideGuard(2.9, by: 2.9)
func divide1(_ number: Double,by divisor: Double){
    if divisor == 0.0 {
        return
    }
    let result = number/divisor
    print(result)
}

divide1(2.9, by: 2.9)

///Guard con opcionales
///
struct goose {
    var eggs: Int?
    var name: String
    init (eggs: Int?, name: String){
        self.eggs = eggs
        self.name = name
    }
}

var goose1 = goose(eggs: 1, name: "Vico")

if let eggs = goose1.eggs {
    print("El ganzo puso \(eggs) huevos")
}
//egss no es accesible aquí, debido a que si la condición es falsa, el valor "eggs" deja de existir


func huevos(goose: goose){
    guard let eggs = goose.eggs else {
        print("No tiene huevos")
        return
    }
    
    print("La oca puso \(eggs) huevos.")
}
huevos(goose: goose(eggs: nil, name: "Pablo"))

func processBook(tittle: String?, price: Double?, pages: Int?){
    if let theTitle = tittle,
       let thePrice = price,
       let thePages = pages {
        print("\(theTitle) cuesta $\(thePrice) y tiene \(thePages)")
    }
    else {
        print("El libro no contiene alguno de los elementos necesarios para poder ser registrado")
    }
}

func processBookGuard(tittle: String?, price: Double?, pages: Int?){
    guard let theTitle = tittle,
          let thePrice = price,
          let thePages = pages else {
        print("El libro no contiene alguno de los elementos necesarios para poder ser registrado")
        return
    }
    print("\(theTitle) cuesta $\(thePrice) y tiene \(thePages)")
}
