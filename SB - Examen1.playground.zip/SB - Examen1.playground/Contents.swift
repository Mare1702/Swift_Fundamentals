import UIKit
/*Programa que usa a un numero entero y otro double para*/
enum opciones{
    case Suma
    case Resta
    case Multiplicación
    case División
    case Resto
}
print("\t\t\t\t\tCalculadora")
print("Según la opción en para la variable 'Opción' tendremos los siguientes casos:\n")
print("1. Suma\t2.Resta\t3.Multiplicación\t4.División\t5.Resto")
print("Los valores a operar estarán dados como parámetros a la función 'calculadora'")

func calculadora(a numero1: Int, y numero2: Double, con calculo: opciones){
    var resultado: Double
    switch calculo{
        
    case .Suma:
        print("SUMA")
        resultado = Double(numero1) + numero2
        print("El resultado de la suma es: \(resultado)")
        
    case .Resta:
        print("RESTA")
        resultado = Double(numero1) - numero2
        print("El resultado de la resta es: \(resultado)")
        
    case .División:
        print("DIVISIÓN")
        resultado = Double(numero1) / numero2
        print("El resultado de la división es: \(resultado)")
        
    case .Multiplicación:
        print("MULTIPLICACIÓN")
        resultado = Double(numero1) * numero2
        print("El resultado de la multiplicación es: \(resultado)")
        
    case .Resto:
        print("RESTO")
        resultado = Double(numero1) .truncatingRemainder(dividingBy: numero2)
        print("El residuo restante de la divición es: \(resultado)")
    }
}

calculadora(a: 4, y: 7.2, con: .Resta)

