import UIKit

//Generación de una Clase "Coche"
/*class CochePadre {                                //Palabra reservada "class" para definir a una clase
    var modelo: String = "2000"
    let numRuedas: Int = 4
    var velocidadInicio: Double = 0.0
    
    var description: String {
        
        "El modelo del vehiculo es: \(modelo), tiene \(numRuedas) ruedas, y su velocidad de inicio es: \(velocidadInicio)"
    }
    
}

//Justo como en una estructura, se necesita una instancia de la clase para poder emplear sus metodos y atributos
let informaciónVehiculo = CochePadre()
print(informaciónVehiculo.description)

//Generación de una subclase, o clase hija a partir de la que ya hemos creado

class CocheHijo: CochePadre {
    var tpo: String = "Suburban"
    var precio: Double = 1_000_000
    let version: Int = 2023
    
    var description2: String {
        "Modelo: \(modelo), precio: \(precio), version: \(version)"
    }
}*/

//Ejemplo 2

class Madre{
    let Apellido: String = "Hernández"
    let Nombre: String = "Claudia"
    var Estatura: Double = 1.63
    var Edad: Int = 60
    var Presentación: String {
        "Ella es \(Nombre) \(Apellido), mide \(Estatura) y tiene \(Edad) años"
    }
}
var Madre1 = Madre()
print(Madre1.Presentación)

class Hija: Madre{
    let Estarura = 1.66
}
