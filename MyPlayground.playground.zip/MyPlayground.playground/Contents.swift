import UIKit

var greeting = "Hello, playground"
var variable = 3

